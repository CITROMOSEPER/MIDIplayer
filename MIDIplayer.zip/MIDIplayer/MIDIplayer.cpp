//MIDIplayer library source file
//ESP32
//2024/08/18
//Nemes Dániel



#include <Arduino.h>
#include <MIDIplayer.h>


//All the notes frequencies
const float MIDIplayer::_frequencies[85] = {32.703, 34.648, 36.708, 38.891, 41.203, 43.654, 46.249, 48.999, 51.913, 55, 58.913, 61.735, 65.406, 69.296, 73.416, 77.782, 82.407, 87.307,92.499, 97.999, 103.826, 110, 116.471, 123.471, 130.813, 138.591, 146.832, 155.563, 164.814, 174.614, 184.997, 195.998, 207.652, 220, 233.082, 246.942, 261.626, 277.183, 293.665, 311.127, 329.628, 349.228, 369.994, 391.995, 415.305, 440, 466.164, 493.883, 523.251, 554.365, 587.33, 622.254, 659.255, 698.456, 739.989, 783.991, 830.609, 880, 932.328, 987.767, 1046.502, 1108.731, 1174.659, 1244.508, 1318.51, 1396.913, 1479.978, 1567.982, 1661.219, 1760, 1864.655, 1975.533, 2093.005, 2217.461, 2349.318, 2489.016, 2637.021, 2793.826, 2959.955, 3135.964, 3322.438, 3520, 3729.31, 3951.066, 4186.009};


//constructor funciton
MIDIplayer::MIDIplayer(int outputPin, int BPM)
{
	_outputPin = outputPin;
	_BPM = BPM;
	_beatLength = 60000 / _BPM;		//Time for each beat
	_terminated = 0;
}


//Initializer function
void MIDIplayer::begin()
{
	pinMode(_outputPin, OUTPUT);
	_beatLength = 60000 / _BPM;		//Time for each beat
}


//Set BPM after initialization
void MIDIplayer::setBPM(int BPM)
{
	_BPM = BPM;
	_beatLength = 60000 / _BPM;		//Time for each beat
}


//Play music
void MIDIplayer::playMidiString(String MIDI_string)
{
	int noteID = 0;
	int length = MIDI_string.length();
	for (int i = 0; i < length; i++)
	{
		char letter = MIDI_string.charAt(i);
		switch (letter)
		{
			case '0':
				_octave = 0;
				noteID = 2000;
				break;
			case '1':
				_octave = 1;
				noteID = 2000;
				break;
			case '2':
				_octave = 2;
				noteID = 2000;
				break;
			case '3':
				_octave = 3;
				noteID = 2000;
				break;
			case '4':
				_octave = 4;
				noteID = 2000;
				break;
			case '5':
				_octave = 5;
				noteID = 2000;
				break;
			case '6':
				_octave = 6;
				noteID = 2000;
				break;
			case ' ':
				noteID = 2000;
				break;

			case 'c':
				noteID = (_octave * 12) + 0;
				break;
			case 'C':
				noteID = (_octave * 12) + 1;
				break;
			case 'd':
				noteID = (_octave * 12) + 2;
				break;
			case 'D':
				noteID = (_octave * 12) + 3;
				break;
			case 'e':
				noteID = (_octave * 12) + 4;
				break;
			case 'f':
				noteID = (_octave * 12) + 5;
				break;
			case 'F':
				noteID = (_octave * 12) + 6;
					break;
			case 'g':
				noteID = (_octave * 12) + 7;
				break;
			case 'G':
				noteID = (_octave * 12) + 8;
				break;
			case 'a':
				noteID = (_octave * 12) + 9;
				break;
			case 'A':
				noteID = (_octave * 12) + 10;
				break;
			case 'b':
				noteID = (_octave * 12) + 11;
				break;

			//case '-':
			//	noTone(_outputPin);
			//	noteID = 1000;

			default:
				noteID = 1000;
				break;
		}
		
		if (_terminated == 0)
		{
			//If noteID is less than 1000, play note normally, for undefined time
			if (noteID < 1000)
			{
				tone(_outputPin, _frequencies[noteID]);
			}
			//If noteid is above 1000, mute note
			else
			{
				noTone(_outputPin);
			}
			//If noteID is exactly 1000, delay until next beat
			if (noteID <= 1000)
			{
				delay(_beatLength);
			}
		}
	}
	_terminated = 0;
}


//Terminates the currently played MIDI string
void MIDIplayer::terminate()
{
	_terminated = 1;
	noTone(_outputPin);
}