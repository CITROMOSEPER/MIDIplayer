//MIDIplayer library header file
//ESP32
//2024/08/18
//Nemes Dániel

#ifndef MIDIplayer_h
#define MIDIplayer_h

#include <Arduino.h>

class MIDIplayer
{
  public:
		MIDIplayer(int outputPin, int BPM);
		void begin();
		void setBPM(int BPM);
		void playMidiString(String MIDI_string);
		void terminate();

	private:
		int _outputPin;
		int _BPM;
		int _beatLength;
		static const float _frequencies[85];
		int _octave;
		int _terminated;

};

#endif